<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model frontend\models\CCTV */

$this->title = 'Update Cctv: ' . ' ' . $model->lokasi;
$this->params['breadcrumbs'][] = ['label' => 'CCTV', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_cctv, 'url' => ['view', 'id' => $model->id_cctv]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="panel panel-primary">
	<div class="panel-heading">
    	<?= Html::encode($this->title) ?>  
    </div>
    <div class="panel-body">
    	<div class="cctv-update">

			<?= $this->render('_form', [
                'model' => $model,
            ]) ?>
        
        </div>
    </div>
</div>
