<?php

return [
    'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=localhost;dbname=dishubkabbandung',
	'username' => 'root',
	'password' => 'root',
	'charset' => 'utf8',
];
